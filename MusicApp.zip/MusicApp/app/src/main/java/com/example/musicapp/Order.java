package com.example.musicapp;

public class Order {
    String username;
    double price;
    String productName;
    double onePrice;
    int quantity;
}
