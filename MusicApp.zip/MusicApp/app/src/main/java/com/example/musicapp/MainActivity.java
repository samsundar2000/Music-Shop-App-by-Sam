package com.example.musicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    TextView textView;
    TextView priceText;
    ImageView imageView2;
    EditText editText;
    int num=0;
    ArrayList ary;
    Spinner spinner;
    ArrayAdapter adapter;
    HashMap map;
    String goodsName;
    double price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView5);
        priceText = findViewById(R.id.textView4);
        imageView2 = findViewById(R.id.imageView2);
        editText = findViewById(R.id.editText);
        spinner = findViewById(R.id.spinner);
        hashMap();
        createSpinner();

    }
    public void hashMap(){
        ary = new ArrayList();
        ary.add("Guitar");
        ary.add("Keyboard");
        ary.add("Drums");
        map = new HashMap();
        map.put("Guitar",1500.0);
        map.put("Keyboard",1000.0);
        map.put("Drums",300.0);
    }

    public void createSpinner(){
        adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,ary);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

    }
    public void clickListener(View view){
        num++;
        textView.setText(""+num);
        price = (double)map.get(goodsName);
        priceText.setText(""+num*price+"$");

    }
    public void clickListener1(View view){
        num--;
        if(num<0){
            num=0;
        }
        textView.setText(""+num);
        price = (double)map.get(goodsName);
        priceText.setText(""+num*price+"$");
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        goodsName = spinner.getSelectedItem().toString();
        price = (double)map.get(goodsName);
        priceText.setText(""+num*price+"$");
        if(goodsName.equals("Drums")){
            imageView2.setImageResource(R.drawable.drums);
        }
        else if(goodsName.equals("Keyboard")){
            imageView2.setImageResource(R.drawable.keyboard);
        }
        else if(goodsName.equals("Guitar")){
            imageView2.setImageResource(R.drawable.guitar);
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void addToChar(View view) {
        Order obj = new Order();
        obj.username = editText.getText().toString();
        obj.productName = goodsName;
        obj.quantity = num;
        obj.price = num*price;
        obj.onePrice = price;
        Intent intent = new Intent(MainActivity.this,MainActivity2.class);
        intent.putExtra("UserName",obj.username);
        intent.putExtra("ProductName",obj.productName);
        intent.putExtra("Quantity",obj.quantity);
        intent.putExtra("Price",obj.price);
        intent.putExtra("oneprice",obj.onePrice);

        startActivity(intent);

    }
}