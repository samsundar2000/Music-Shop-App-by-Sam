package com.example.musicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    String edittext;
    String[] addresses ={"MusicShop@gmail.com"};
    String subject="Order From Music Shop";
    String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Your Order");
        setContentView(R.layout.activity_main2);
        Intent obj = getIntent();
        String name = obj.getStringExtra("UserName");
        String productName = obj.getStringExtra("ProductName");
        int quantity = obj.getIntExtra("Quantity",0);
        double onePrice = obj.getDoubleExtra("oneprice",0);
        double price = obj.getDoubleExtra("Price",0);
        TextView txt = findViewById(R.id.textView6);
        edittext = "UserName: "+" "+name+"\n"+"Product Name: "+" "+productName+"\n"+"Quantity: "+" "+quantity+"\n"+"Price: "+" "+onePrice+"\n"+"Total Price: "+" "+price;
        txt.setText(edittext);
    }

    public void submitButton(View view){
        
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT,edittext);
        if(intent.resolveActivity(getPackageManager())!= null){
            startActivity(intent);

        }
    }
}